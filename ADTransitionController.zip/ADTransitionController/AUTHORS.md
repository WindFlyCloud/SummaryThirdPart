Copyright (c) 2013, Applidium

This file contains the list of people involved in the development
of ADTransitionController along its history.

==========================================================

* Romain Goyet
	- Co-architect
	- Runtime trick to add transitionController property
	- Implementation of the ZoomTransition
* Patrick Nollet
	- Co-architect
	- Implementation of most of the transitions : ADCarrouselTransition, ADCubeTransition, ADCrossTransition, ADFlipTransition, ADSwapTransition, ADFadeTransition, ADBackFadeTransition, ADGhostTransition, ADSwipeTransition, 
* Pierre Felgines
	- Improve ADTransitionController API to match UINavigationController API
	- Implementation of some transitions : ADSwipeFadeTransition, ADScaleTransition, ADGlueTransition, ADPushRotateTransition, ADFoldTransition, ADSlideTransition
* Angélique Calmon
	- UI design