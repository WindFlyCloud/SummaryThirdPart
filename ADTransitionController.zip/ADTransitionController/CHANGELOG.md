## 1.1.1 (16 October 2014)

Migration to ARC (fixes #23)

## 1.1.0 (17 December 2013)

iOS7 integration

## 1.0.1 (5 November 2013)

Bugfixes:
 - Fix sawtooths during animations
 - Add toolbar support

## 1.0.0 (16 July 2013)

First release
