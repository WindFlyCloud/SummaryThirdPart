AIMTableViewIndexBar
====================

Custom index bar for UITableView

```bash
pod 'AIMTableViewIndexBar', '~> 0.1.1'
```

<p align="center" >
  <img src="https://s3.amazonaws.com/cocoacontrols_production/uploads/control_image/image/1802/IMG_0070.PNG">
</p>
