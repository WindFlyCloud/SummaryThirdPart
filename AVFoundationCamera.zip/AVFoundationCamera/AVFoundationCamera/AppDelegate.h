//
//  AppDelegate.h
//  AVFoundationCamera
//
//  Created by 陈 爱彬 on 13-10-11.
//  Copyright (c) 2013年 陈 爱彬. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ISTMainViewController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) ISTMainViewController *mainVc;

@end
