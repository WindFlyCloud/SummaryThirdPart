//
//  ISTCameraViewController.h
//  ISTHideCameraShutterDemo
//
//  Created by 陈 爱彬 on 13-10-8.
//  Copyright (c) 2013年 陈 爱彬. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{
    ISTCameraFlashModeAuto = 1,
    ISTCameraFlashModeOn,
    ISTCameraFlashModeOff,
}ISTCameraFlashMode;

@interface ISTCameraViewController : UIViewController

@end
