//
//  main.m
//  AVFoundationCamera
//
//  Created by 陈 爱彬 on 13-10-11.
//  Copyright (c) 2013年 陈 爱彬. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
