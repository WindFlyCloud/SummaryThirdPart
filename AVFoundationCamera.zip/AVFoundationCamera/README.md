AVFoundationCamera
==================

利用AVFoundation来自定义相机，支持拍照，翻转前后摄像头，闪光灯等功能。
