//
//  BTConst.h
//  BanTang
//
//  Created by Ryan on 15/11/30.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 *  更新subjectVC数据
 */
extern NSString *const NOTI_UPDATE_SUBJECT_VC_DATA;
