//
//  BTConst.m
//  BanTang
//
//  Created by Ryan on 15/11/30.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import "BTConst.h"

NSString *const NOTI_UPDATE_SUBJECT_VC_DATA= @"NOTI_UPDATE_SUBJECT_VC_DATA";
