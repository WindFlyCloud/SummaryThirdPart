//
//  UIImageView+Extension.h
//  BanTang
//
//  Created by Ryan on 16/1/8.
//  Copyright © 2016年 Ryan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Extension)

- (void)fadeImageWithUrl:(NSString *)url;

@end
