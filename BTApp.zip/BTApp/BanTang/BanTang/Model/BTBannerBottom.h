//
//  BTBannerBottom.h
//  BanTang
//
//  Created by Ryan on 16/3/15.
//  Copyright © 2016年 Ryan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BTBannerBottom : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, assign) NSInteger index;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *extend;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *photo;

@property (nonatomic, copy) NSString *subTitle;

@end
