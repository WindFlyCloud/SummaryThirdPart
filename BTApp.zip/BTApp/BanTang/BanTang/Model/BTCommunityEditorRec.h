//
//  BTCommunityEditorRec.h
//  BanTang
//
//  Created by 沈文涛 on 15/12/6.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BTCommunityEditorRec : NSObject

@property (nonatomic, strong) NSArray *element;

@property (nonatomic, strong) NSArray *list;

@end
