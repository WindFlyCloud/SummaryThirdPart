//
//  BTCommunityElement.m
//  BanTang
//
//  Created by 沈文涛 on 15/12/6.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import "BTCommunityElement.h"

@implementation BTCommunityElement

@end
