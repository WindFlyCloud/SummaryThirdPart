//
//  BTSubjectAuthor.m
//  BanTang
//
//  Created by Ryan on 15/11/27.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import "BTSubjectAuthor.h"
#import <MJExtension.h>
@implementation BTSubjectAuthor

+ (NSString *)mj_replacedKeyFromPropertyName121:(NSString *)propertyName
{
    return [propertyName mj_underlineFromCamel];
}


@end
