//
//  BTSubscribeTag.h
//  BanTang
//
//  Created by 沈文涛 on 15/11/30.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BTSubscribeTag : NSObject

@property (nonatomic, copy) NSString *ID;

@property (nonatomic, copy) NSString *enName;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *icon;

@end
