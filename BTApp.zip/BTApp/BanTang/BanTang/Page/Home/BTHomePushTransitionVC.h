//
//  BTHomePushTransitionVC.h
//  BanTang
//
//  Created by Ryan on 16/1/5.
//  Copyright © 2016年 Ryan. All rights reserved.
//

#import "BTHomeVC.h"
#import "RMPZoomTransitionAnimator.h"

@interface BTHomePushTransitionVC : BTHomeVC <RMPZoomTransitionAnimating>

@end
