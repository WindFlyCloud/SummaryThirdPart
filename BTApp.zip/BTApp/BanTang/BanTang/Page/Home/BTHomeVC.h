//
//  BTHomeVC.h
//  BanTang
//
//  Created by 沈文涛 on 15/11/26.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTHomeVC : UIViewController

@property (nonatomic, strong) UIImageView *cellImageView;

/** 表格视图 */
@property (nonatomic, strong) UITableView *tableView;

@end
