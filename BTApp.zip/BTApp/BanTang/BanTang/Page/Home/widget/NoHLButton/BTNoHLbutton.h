//
//  BTNoHLbutton.h
//  BanTang
//
//  Created by 沈文涛 on 15/11/28.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTNoHLbutton : UIButton

@end
