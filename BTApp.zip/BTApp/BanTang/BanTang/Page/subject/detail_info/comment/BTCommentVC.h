//
//  BTCommentVC.h
//  BanTang
//
//  Created by Ryan on 15/11/30.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTCommentVC : UIViewController

@property (nonatomic, copy) NSString *objectID;

@end
