//
//  BTListPostLikeListVC.h
//  BanTang
//
//  Created by Ryan on 15/11/30.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTListPostLikeListVC : UITableViewController

@property (nonatomic, strong) NSArray *likesUserArray;

@property (nonatomic, copy) NSString *extendID;

@end
