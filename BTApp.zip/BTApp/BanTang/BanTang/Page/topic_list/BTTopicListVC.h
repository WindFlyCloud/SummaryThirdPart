//
//  BTTopicListVC.h
//  BanTang
//
//  Created by Ryan on 15/11/27.
//  Copyright © 2015年 Ryan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTTopicListVC : UIViewController

@property (nonatomic, copy) NSString *extend;

@end
