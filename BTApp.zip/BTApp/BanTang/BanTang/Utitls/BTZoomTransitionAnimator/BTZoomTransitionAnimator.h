//
//  BTZoomTransitionAnimator.h
//  BanTang
//
//  Created by Ryan on 16/1/5.
//  Copyright © 2016年 Ryan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTZoomTransitionAnimator : NSObject <UIViewControllerAnimatedTransitioning>

@end
