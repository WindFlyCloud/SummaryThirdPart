//
//  ViewController.m
//  CustomUI
//
//  Created by LiuTao on 16/1/12.
//  Copyright © 2016年 LiuTao. All rights reserved.
//

#import "ViewController.h"
#import "ProductAddView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UILabel* tLabel = nil;
    tLabel = [[UILabel alloc] init];
    tLabel.frame = CGRectMake(0, 0, self.view.frame.size.width, 35);
    tLabel.center = CGPointMake(self.view.frame.size.width/2, self.view.frame.size.height/2-50);
    tLabel.backgroundColor = [UIColor clearColor];
//    [tLabel setText:@"<#s#>"];
    [tLabel setFont:[UIFont systemFontOfSize:18.f]];
    [tLabel setTextColor:[UIColor blackColor]];
    [self.view addSubview:tLabel];
    
    ProductAddView* addView = [[ProductAddView alloc] initWithFrame:CGRectMake(0, 0, 120, 35)];
    addView.center = self.view.center;
    [self.view addSubview:addView];
    [addView setBlock:^BOOL(NSInteger productNum) {
        tLabel.text = [NSString stringWithFormat:@"您修改的商品数量为：%@",[NSNumber numberWithInteger:productNum]];
        
        return YES;
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
