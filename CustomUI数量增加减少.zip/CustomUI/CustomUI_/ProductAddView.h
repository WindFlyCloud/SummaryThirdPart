//
//  ProductAddView.h
//  CustomUI
//
//  Created by LiuTao on 16/1/12.
//  Copyright © 2016年 LiuTao. All rights reserved.
//


#import <UIKit/UIKit.h>

typedef BOOL(^ProductNumBlock)(NSInteger productNum);
@interface ProductAddView : UIView<UITextFieldDelegate>
{
    UITextField* _tTextField;
}

// UI（默认数：1/frame）

// 回调 （点击加减之后回调/输入完成后回调）

/// 设置回调
-(void) setBlock:(ProductNumBlock)callBack;

/// 设置恢复修改之前 / 设置失去第一相应



@end
