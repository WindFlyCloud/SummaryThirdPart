//
//  ProductAddView.m
//  CustomUI
//
//  Created by LiuTao on 16/1/12.
//  Copyright © 2016年 LiuTao. All rights reserved.
//

#import "ProductAddView.h"

@interface ProductAddView ()

@property (nonatomic, strong) ProductNumBlock callBack;

@end
@implementation ProductAddView


-(void) setBlock:(ProductNumBlock)callBack;
{
    self.callBack = callBack;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        float btnW = self.frame.size.width/3;
        float btnH = self.frame.size.height;

//        UIColor* color = [UIColor redColor];
        UITextField* tTextField = nil;
        tTextField = [[UITextField alloc] init];
        tTextField.frame = CGRectMake(btnW, 0, btnW, frame.size.height);
        tTextField.delegate = self;
        [tTextField setText:@"1"];
        [tTextField setFont:[UIFont boldSystemFontOfSize:15.f]];
        [tTextField setTextColor:[UIColor redColor]];
        tTextField.textAlignment = NSTextAlignmentCenter;
        tTextField.keyboardType = UIKeyboardTypeNumberPad;
        [tTextField setContentVerticalAlignment:UIControlContentVerticalAlignmentCenter];//垂直居中
        [self addSubview:tTextField];
        _tTextField = tTextField;
        
        UIButton* tButton = nil;
        tButton = [UIButton buttonWithType:UIButtonTypeCustom];
        tButton.frame = CGRectMake(0, 0, btnW, btnH);
        tButton.tag = 50;
        [tButton setTitle:@"-" forState:UIControlStateNormal];
        [tButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [tButton.titleLabel setFont:[UIFont boldSystemFontOfSize:20.f]];
        [tButton addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:tButton];
//        [tTextField setLeftView:tButton];
        
        tButton = [UIButton buttonWithType:UIButtonTypeCustom];
        tButton.frame = CGRectMake(btnW*2, 0, btnW, btnH);
        tButton.tag = 51;
        [tButton setTitle:@"+" forState:UIControlStateNormal];
        [tButton setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [tButton.titleLabel setFont:[UIFont boldSystemFontOfSize:20.f]];
        [tButton addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:tButton];
        
    }
    return self;
}

-(void) btnClick:(UIButton*)button
{
    NSInteger tag = [button tag];
    NSInteger num = [_tTextField.text integerValue];

    if (tag == 50) {
        // 1.取出来数字  2.先判断是否可以减  3.减  4.设置textfield  5.回调---  6.判断返回值 如果失败 该步操作需要回滚
        if (num <= 1) {
            NSLog(@" 不能再减少了");
        }else{
            num -= 1;
            _tTextField.text = [[NSNumber numberWithInteger:num] description];
            if (self.callBack) {
                self.callBack(num);
//                BOOL isSuccess = self.callBack(num);
//                NSLog(@"是否减少成功：%d",isSuccess);
//                if (!isSuccess) {
//                    NSLog(@" 不能再减少了");
//                }
            }
        }
        
    }else{
        // 1.取出来数字  2.先判断是否可以加  3.减  4.设置textfield  5.回调---  6.判断返回值 如果失败 该步操作需要回滚
        num += 1;
        _tTextField.text = [[NSNumber numberWithInteger:num] description];
        if (self.callBack) {
            self.callBack(num);
        }
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField;             // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
{
    NSInteger num = [_tTextField.text integerValue];
//    num += 1;
//    _tTextField.text = [[NSNumber numberWithInteger:num] description];
    if (self.callBack) {
        self.callBack(num);
    }
}

@end
