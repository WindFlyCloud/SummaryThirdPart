//
//  DZAppDelegate.h
//  DZVideoPlayerViewController
//
//  Created by CocoaPods on 06/03/2015.
//  Copyright (c) 2014 Denis Zamataev. All rights reserved.
//

@import UIKit;

@interface DZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
