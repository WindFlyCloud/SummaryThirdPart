//
//  DZViewController.h
//  DZVideoPlayerViewController
//
//  Created by Denis Zamataev on 06/03/2015.
//  Copyright (c) 2014 Denis Zamataev. All rights reserved.
//

@import UIKit;

#import <DZVideoPlayerViewController/DZVideoPlayerViewController.h>

@interface DZViewController : UIViewController

@end
