//
//  main.m
//  DZVideoPlayerViewController
//
//  Created by Denis Zamataev on 06/03/2015.
//  Copyright (c) 2014 Denis Zamataev. All rights reserved.
//

@import UIKit;
#import "DZAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DZAppDelegate class]));
    }
}
