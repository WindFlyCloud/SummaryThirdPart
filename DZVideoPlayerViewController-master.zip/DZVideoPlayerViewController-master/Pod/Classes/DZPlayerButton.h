//
//  DZPlayerButton.h
//  Pods
//
//  Created by Denis Zamataev on 03/06/15.
//
//

#import <UIKit/UIKit.h>

@interface DZPlayerButton : UIButton

@end
