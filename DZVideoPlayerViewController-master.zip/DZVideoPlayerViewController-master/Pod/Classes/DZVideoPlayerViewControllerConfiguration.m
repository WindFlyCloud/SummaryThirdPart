//
//  DZVideoPlayerViewControllerConfiguration.m
//  Pods
//
//  Created by Denis Zamataev on 15/07/15.
//
//

#import "DZVideoPlayerViewControllerConfiguration.h"

@implementation DZVideoPlayerViewControllerConfiguration

@end
