//
//  DZVideoPlayerViewController_constants.h
//  Pods
//
//  Created by Denis Zamataev on 01/06/15.
//
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, DZVideoPlayerViewControllerStyle) {
    DZVideoPlayerViewControllerStyleDefault = 0,
    DZVideoPlayerViewControllerStyleSimple = 1
};