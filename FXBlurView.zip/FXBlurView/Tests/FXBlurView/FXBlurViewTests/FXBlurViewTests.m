//
//  FXBlurViewTests.m
//  FXBlurViewTests
//
//  Created by Ashton Williams on 29/04/2014.
//  Copyright (c) 2014 Charcoal Design. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface FXBlurViewTests : XCTestCase

@end

@implementation FXBlurViewTests

@end
