//
//  AppDelegate.h
//  FunctionGuiding
//
//  Created by wbxiaowangzi on 16/2/24.
//  Copyright © 2016年 上海燃耀. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

