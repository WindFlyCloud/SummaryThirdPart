//
//  RAYNewFunctionGuideVC.h
//  hooray
//
//  Created by wbxiaowangzi on 16/2/23.
//  Copyright © 2016年 RAY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RAYNewFunctionGuideVC : UIViewController
@property (nonatomic, strong) NSArray *titles;
@property (nonatomic, strong) NSArray *frames;
@end
