# FunctionGuideController
新功能引导控制器，传入两个数组就能使用，由于添加了自定义字体，和图片资源，所以比较大，代码本身并不大

![Aaron Swartz](https://github.com/wbxiaowangzi/FunctionGuideController/blob/master/FunctionGuide.gif)
