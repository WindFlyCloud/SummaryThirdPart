//
//  Config.h
//  easyride_kuaiji
//
//  Created by JET on 15/9/11.
//  Copyright (c) 2015年 JET. All rights reserved.
//

#ifndef easyride_kuaiji_Config_h
#define easyride_kuaiji_Config_h

// 请求超时
#define HTTP_REQUEST_TIMEOUT        12.f
// 接收的返回值类型
#define ACCEPTABLE_CONTENT_MIMETYPES [NSSet setWithObjects:@"application/json", @"text/json", @"text/plain",@"text/html", nil]


#endif
