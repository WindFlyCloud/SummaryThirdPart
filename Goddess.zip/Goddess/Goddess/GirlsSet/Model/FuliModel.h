//
//  FuliModel.h
//  Goddess
//
//  Created by wangyan on 2016－03－17.
//  Copyright © 2016年 Goddess. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FuliModel : NSObject
@property (nonatomic,strong) NSString * url;
@end
