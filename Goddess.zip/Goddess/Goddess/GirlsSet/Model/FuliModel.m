//
//  FuliModel.m
//  Goddess
//
//  Created by wangyan on 2016－03－17.
//  Copyright © 2016年 Goddess. All rights reserved.
//

#import "FuliModel.h"

@implementation FuliModel

@end
