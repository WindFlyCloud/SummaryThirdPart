//
//  PhotoBrowerBaseCell.h
//  Goddess
//
//  Created by wangyan on 2016－03－17.
//  Copyright © 2016年 Goddess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PhotoBrowerBaseCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView * imageView;
@end
