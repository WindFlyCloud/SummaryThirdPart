//
//  PhotoViewCell.h
//  myHelper
//
//  Created by wangyan on 2016－03－15.
//  Copyright © 2016年 idea. All rights reserved.
//

#import "PhotoBrowerBaseCell.h"

@interface PhotoBrowerOriginCell : PhotoBrowerBaseCell
- (void)reuse;
@end
