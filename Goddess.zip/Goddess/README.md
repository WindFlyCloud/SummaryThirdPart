# Goddess
# 这其实是一个相册的示例程序（美女不重要）
一个OC版的看图程序 

模仿系统相册联系的时候顺便搞出来的. 数据来自 [http://gank.io/](http://gank.io/) by [@daimajia](https://github.com/daimajia).

API of gank.io: [http://gank.io/api](http://gank.io/api).

### Demo

<img src="https://raw.githubusercontent.com/jlideasoft/pictures/master/meinvmen.gif" width="320"><br/>
<img src="https://raw.githubusercontent.com/jlideasoft/pictures/master/meinvmen1.png" width="320"><br/>
<img src="https://raw.githubusercontent.com/jlideasoft/pictures/master/meinvmen2.png" width="320"><br/>



### License

The MIT License (MIT)

