GuGuSegmentNaviViewController
=============================

一个仿网易新闻客户端iPhone版的标签式导航ViewController
效果与网易新闻客户端的标签式导航基本一样：
（1）点击上面的标签，可以显示对应的controller，标签下面的红色提示条的长度会动态变化。
（2）对下面的内容区左滑或者右滑可以显示对应的controller，标签会同时变化。
