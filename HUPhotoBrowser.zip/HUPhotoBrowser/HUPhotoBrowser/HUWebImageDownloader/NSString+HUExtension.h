//
//  NSString+HUExtension.h
//  HUPhotoBrowser
//
//  Created by mac on 16/2/25.
//  Copyright (c) 2016年 hujewelz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HUExtension)

- (NSString *)hu_md5;

@end
