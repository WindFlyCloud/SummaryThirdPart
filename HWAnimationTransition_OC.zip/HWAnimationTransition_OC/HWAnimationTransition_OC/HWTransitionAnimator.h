//
//  HWTransitionAnimator.h
//  HWAnimationTransition_OC
//
//  Created by HenryCheng on 16/3/16.
//  Copyright © 2016年 www.igancao.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface HWTransitionAnimator : NSObject

@end
