# HWAnimationTransition_OC
一个放大效果的转场动画（OC版）
效果如下

![拖拽动画](https://github.com/Loveway/HWAnimationTransition_OC/blob/master/pan_oc.gif)
![拖拽动画](https://github.com/Loveway/HWAnimationTransition_OC/blob/master/tap_oc.gif)

具体实现原理，请看[我的简书](http://www.jianshu.com/p/8c29fce5a994)
