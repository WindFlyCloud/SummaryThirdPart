//
//  BrandStoryViewController.h
//  HomeForCar
//
//  Created by _ziTai on 16/3/12.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BrandStoryViewController : UIViewController
@property(nonatomic,copy)NSString *story;
@end
