//
//  CarTableViewController.h
//  HomeForCar
//
//  Created by _ziTai on 16/3/8.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarTableViewController : UITableViewController
@property(nonatomic,retain)NSArray *arr;
@property(nonatomic,assign)NSInteger a1;
@property(nonatomic,assign)NSInteger b1;
@property(nonatomic,assign)NSInteger a2;
@property(nonatomic,assign)NSInteger b2;
@property(nonatomic,assign)NSInteger a3;
@property(nonatomic,assign)NSInteger b3;
@property(nonatomic,assign)NSInteger a4;
@property(nonatomic,assign)NSInteger b4;
@end
