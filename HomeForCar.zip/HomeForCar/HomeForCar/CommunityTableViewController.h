//
//  CommunityTableViewController.h
//  HomeForCar
//
//  Created by _ziTai on 16/3/8.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommunityTableViewController : UITableViewController
@property(nonatomic,retain)NSArray *arr;
@end
