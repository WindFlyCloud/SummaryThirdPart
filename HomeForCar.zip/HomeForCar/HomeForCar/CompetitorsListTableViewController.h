//
//  CompetitorsListTableViewController.h
//  HomeForCar
//
//  Created by _ziTai on 16/3/11.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CompetitorsListTableViewController : UITableViewController
@property(nonatomic,retain)NSArray *arr;
@end
