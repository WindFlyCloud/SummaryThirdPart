//
//  DetailCarListTableViewController.h
//  HomeForCar
//
//  Created by _ziTai on 16/3/11.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailCarListTableViewController : UITableViewController
@property(nonatomic,retain)NSArray *arr;
@property(nonatomic,assign)NSInteger segIndex;
@end
