//
//  HeadCollectionReusableView.m
//  HomeForCar
//
//  Created by _ziTai on 16/3/11.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import "HeadCollectionReusableView.h"

@implementation HeadCollectionReusableView

- (void)awakeFromNib {
    // Initialization code
}

@end
