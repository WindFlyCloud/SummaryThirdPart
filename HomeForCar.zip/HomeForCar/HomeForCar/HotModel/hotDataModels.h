//
//  DataModels.h
//
//  Created by mac  on 16/3/7
//  Copyright (c) 2016 __MyCompanyName__. All rights reserved.
//

#import "hotAuthor.h"#import "hotDetail.h"#import "hotItemList.h"#import "hotData.h"#import "hotImageList.h"#import "hotList.h"#import "hotHotModel.h"