//
//  NewDetailTableViewController.h
//  HomeForCar
//
//  Created by _ziTai on 16/3/10.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewDetailTableViewController : UIViewController
@property(nonatomic,copy)NSString *artID;
@end
