//
//  ProgressTableViewCell.m
//  HomeForCar
//
//  Created by _ziTai on 16/3/14.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import "ProgressTableViewCell.h"

@implementation ProgressTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
