//
//  TableHeadView.h
//  HomeForCar
//
//  Created by _ziTai on 16/3/15.
//  Copyright © 2016年 _ziTai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableHeadView : UIView
@property (weak, nonatomic) IBOutlet UIButton *loginButton;

@end
