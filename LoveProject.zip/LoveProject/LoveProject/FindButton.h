//
//  FindButton.h
//  LoveProject
//
//  Created by WindFlyCloud on 16/3/8.
//  Copyright © 2016年 caoxu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FindButton : UIButton

@property (nonatomic,strong) UIImageView * bgImage;

@property (nonatomic,strong) UILabel     * titleLB;

@property (nonatomic,strong) NSIndexPath * indexP;

@end
