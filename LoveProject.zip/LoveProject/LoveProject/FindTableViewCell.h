//
//  FindTableViewCell.h
//  LoveProject
//
//  Created by WindFlyCloud on 16/3/8.
//  Copyright © 2016年 caoxu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FindButton.h"
@interface FindTableViewCell : UITableViewCell


@property (nonatomic,strong) NSMutableArray * btnArr;

@end
