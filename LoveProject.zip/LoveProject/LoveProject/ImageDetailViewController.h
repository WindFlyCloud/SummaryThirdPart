//
//  ImageDetailViewController.h
//  LoveProject
//
//  Created by WindFlyCloud on 16/3/5.
//  Copyright © 2016年 caoxu. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface ImageDetailViewController : UIViewController
@property (nonatomic,copy)NSString * cotentID;
@property (nonatomic,copy)NSString * imageUrl;
@property (nonatomic,assign) float scale;
@end
