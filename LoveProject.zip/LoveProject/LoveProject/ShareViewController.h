//
//  ShareViewController.h
//  LoveProject
//
//  Created by WindFlyCloud on 16/3/7.
//  Copyright © 2016年 caoxu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShareViewController : UIViewController

@property (nonatomic,copy) NSString * titleLB;

@end
