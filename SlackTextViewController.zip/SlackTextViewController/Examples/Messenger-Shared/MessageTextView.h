//
//  MessageTextView.h
//  Messenger
//
//  Created by Ignacio Romero Z. on 1/20/15.
//  Copyright (c) 2015 Slack Technologies, Inc. All rights reserved.
//

#import "SLKTextView.h"

@interface MessageTextView : SLKTextView

@end
