//
//  ViewController.h
//  Messenger
//
//  Created by Ignacio Romero Z. on 4/8/15.
//  Copyright (c) 2015 Slack Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)showMessages:(id)sender;

@end
