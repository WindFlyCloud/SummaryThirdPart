//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "SLKTextViewController.h"

@interface ___FILEBASENAMEASIDENTIFIER___ : SLKTextViewController

@end
