//
//  AppDelegate.m
//  HostApp
//
//  Created by Ignacio Romero on 1/18/16.
//  Copyright © 2016 Slack Technologies, Inc. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}

@end
