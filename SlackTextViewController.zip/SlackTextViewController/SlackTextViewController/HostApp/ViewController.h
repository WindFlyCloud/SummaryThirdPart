//
//  ViewController.h
//  HostApp
//
//  Created by Ignacio Romero on 1/18/16.
//  Copyright © 2016 Slack Technologies, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end

