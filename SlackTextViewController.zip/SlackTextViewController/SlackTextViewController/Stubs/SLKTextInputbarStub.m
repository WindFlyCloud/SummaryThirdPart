//
//  SLKTextInputbarStub.m
//  Messenger
//
//  Created by Ignacio Romero Z. on 3/28/15.
//  Copyright (c) 2015 Slack Technologies, Inc. All rights reserved.
//

#import "SLKTextInputbarStub.h"

@implementation SLKTextInputbarStub

@end
