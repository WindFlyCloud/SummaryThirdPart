//
//  AppDelegate.h
//  HostApp
//
//  Created by Ignacio Romero Z. on 4/18/15.
//  Copyright (c) 2015 Slack Technologies Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

