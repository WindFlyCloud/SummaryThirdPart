//
//  AppDelegate.m
//  HostApp
//
//  Created by Ignacio Romero Z. on 4/18/15.
//  Copyright (c) 2015 Slack Technologies Inc. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
//    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//    self.window.backgroundColor = [UIColor whiteColor];
//    
//    self.window.rootViewController = [UIViewController new];
//    [self.window makeKeyAndVisible];
    
    return NO;
}

@end
