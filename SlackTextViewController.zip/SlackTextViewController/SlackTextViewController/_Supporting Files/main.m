//
//  main.m
//  HostApp
//
//  Created by Ignacio Romero Z. on 4/18/15.
//  Copyright (c) 2015 Slack Technologies Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
