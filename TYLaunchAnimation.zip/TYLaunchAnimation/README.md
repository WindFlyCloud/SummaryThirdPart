# TYLaunchAnimation
launching image or view Animation,UIView Category,easy to use.

启动图动画，带广告，封装成UIView分类，直接使用，支持自定义view，自定义动画。
<br>新增点击URL及跳转。

### screenshot
1.带广告启动页动画<br>
![image](https://raw.githubusercontent.com/12207480/TYLaunchAnimation/master/screenshot/TYLanunchAnimaiton1.gif)
![image](https://raw.githubusercontent.com/12207480/TYLaunchAnimation/master/screenshot/TYLanunchAnimaiton3.gif)
<br>2.启动页动画<br>
![image](https://raw.githubusercontent.com/12207480/TYLaunchAnimation/master/screenshot/TYLanunchAnimaiton2.gif)


demo launchimage 来源于网易，it之家app，仅供demo使用。
