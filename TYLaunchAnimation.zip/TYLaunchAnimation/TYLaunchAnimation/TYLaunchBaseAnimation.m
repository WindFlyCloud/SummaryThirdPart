//
//  TYLaunchBaseAnimation.m
//  TYLaunchAnimationDemo
//
//  Created by tanyang on 15/12/4.
//  Copyright © 2015年 tanyang. All rights reserved.
//

#import "TYLaunchBaseAnimation.h"

@implementation TYLaunchBaseAnimation

- (void)configureAnimationWithView:(UIView *)view completion:(void (^)(BOOL))completion
{
    NSLog(@"please implement TYLaunchAnimationProtocol");
}

@end
