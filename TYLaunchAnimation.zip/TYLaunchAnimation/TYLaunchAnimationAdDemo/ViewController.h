//
//  ViewController.h
//  TYLaunchAnimationAdDemo
//
//  Created by tanyang on 15/12/8.
//  Copyright © 2015年 tanyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

