//
//  TableViewCell.m
//  TableSection
//
//  Created by macrong on 15/6/3.
//  Copyright (c) 2015年 macRong. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
