//
//  main.m
//  TableSection
//
//  Created by macrong on 15/6/3.
//  Copyright (c) 2015年 macRong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
