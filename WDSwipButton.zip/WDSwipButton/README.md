# WDSwipButton
吸附效果的拖拽按钮

**效果**

<p align="left" >
  <img src="preview.gif" alt="preview" title="preview" width = "320">
</p>
