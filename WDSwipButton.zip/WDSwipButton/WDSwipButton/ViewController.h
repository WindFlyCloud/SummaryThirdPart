//
//  ViewController.h
//  WDSwipButton
//
//  Created by 吴迪玮 on 16/2/17.
//  Copyright © 2016年 DNT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WDSwipButton.h"

@interface ViewController : UIViewController<WDSwipButtonDelegate>


@end

