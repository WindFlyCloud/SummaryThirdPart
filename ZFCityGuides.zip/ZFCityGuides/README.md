# ZFCityGuides
使用方法：

1. 打开.xcworkspace编译运行即可
 
高仿City Guides 动画效果

详细参见简书：

[干货系列之实现City Guides的动画效果(一)](http://www.jianshu.com/p/d8e7cc5b307b)

[干货系列之实现City Guides的动画效果(二)](http://www.jianshu.com/p/4bebbb4bfc38)

此demo仅供学习交流使用。

部分动画效果：

动画效果1：
<p align="center" >
<img src="http://upload-images.jianshu.io/upload_images/1255171-50b3cf8b9bcd718d.gif" width="266" height="500"/>
</p>

动画效果2：
<p align="center" >
<img src="http://upload-images.jianshu.io/upload_images/1255171-34621cd10ae0c1c2.gif" width="266" height="500"/>
</p>

动画效果3：

<p align="center" >
<img src="http://upload-images.jianshu.io/upload_images/1255171-e55dedda1d88e9c8.gif" width="266" height="500"/>
</p>

动画效果4：

<p align="center" >
<img src="http://upload-images.jianshu.io/upload_images/1255171-07889b069ecc1427.gif" width="266" height="500"/>
</p>
动画效果5：

<p align="center" >
<img src="http://upload-images.jianshu.io/upload_images/1255171-b20e5c3b0ca66720.gif" width="266" height="500"/>
</p>

动画效果6：

<p align="center" >
<img src="http://upload-images.jianshu.io/upload_images/1255171-58e781b4e3e50192.gif" width="266" height="500"/>
</p>

