//
//  TabBarAnimationController.h
//  ZFCityGuides
//
//  Created by macOne on 16/1/27.
//  Copyright © 2016年 WZF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TabBarAnimationController : NSObject<UIViewControllerAnimatedTransitioning>

@end
