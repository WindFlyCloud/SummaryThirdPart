//
//  ZFLayoutButton.m
//  ZFCityGuides
//
//  Created by macOne on 16/1/11.
//  Copyright © 2016年 WZF. All rights reserved.
//

#import "ZFLayoutButton.h"

@implementation ZFLayoutButton


-(void)setHighlighted:(BOOL)highlighted{
    
}


@end
