//
//  FLAddProductController.h
//  bezierCurveDemo
//
//  Created by 孔凡列 on 16/1/12.
//  Copyright © 2016年 czebd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FLBezierCurveView.h"
@interface FLAddProductController : UIViewController
@property (nonatomic,strong)FLBezierCurveView *cuteView;
@end
