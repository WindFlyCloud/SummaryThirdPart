# shopCartDemo

加入购物车的动画效果:
  ![GIF](https://github.com/wangluhui/image/raw/master/shopList.gif)