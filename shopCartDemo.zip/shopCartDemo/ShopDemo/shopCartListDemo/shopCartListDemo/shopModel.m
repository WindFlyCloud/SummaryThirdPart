//
//  shopModel.m
//  shopCartListDemo
//
//  Created by wanglh on 15/6/4.
//  Copyright (c) 2015年 wanglh. All rights reserved.
//

#import "shopModel.h"

@implementation shopModel

@end
