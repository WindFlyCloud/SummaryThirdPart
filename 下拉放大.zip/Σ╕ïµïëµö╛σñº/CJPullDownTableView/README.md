# CJPullDownTableView
使用UITableView实现下拉放大图片，上拉覆盖图片。
效果如下:  
![](https://github.com/CoderJee/CJPullDownTableView/blob/master/CoderJee.gif)
