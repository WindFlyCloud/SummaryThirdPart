//
//  CJTableViewController.h
//  UITableViewDemo
//
//  Created by CoderJee on 15/1/25.
//  Copyright (c) 2015年 CoderJee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CJTableViewController : UITableViewController

@end
