#CorePullScale
####表格顶部图片下拉放大控件，`一键式安装`，异常简单！


<br /><br /><br />

##框架特性（持续关注[信息公告牌](https://github.com/CharlinFeng/Show)）：<br />
>1.支持所有ios版本（ios6-ios8），没有版本压力！<br />
>2.支持大屏的横竖屏，不再担心横屏变形了。<br />
>3.支持TableView 及 CollectionView 。<br />
>4.自动管理屏幕旋转，无需手动管理。<br />

<br />
##安装说明：<br />
>1.将CorePullScale文件夹放入您的项目中<br />
>2.#import "UIScrollView+PullScale.h"<br />
>3.在ViewdidLoad中直接按以下代码安装即可（图片名换成您对应的图片名）<br />

    [self.tableView addPullScaleFuncInVC:self imgName:@"car@2x.jpg" originalHeight:150 hasNavBar:(self.navigationController!=nil)];
  
<br />
##看看效果图吧
![image](./CorePullScale/img/1.png)
<br /><br />

<br />

-----
    CorePullScale 表格顶部图片下拉放大控件，`一键式安装`，异常简单！   感谢您的关注！ 
-----



<br /><br />



