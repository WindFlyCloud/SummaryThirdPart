//
//  CVC.h
//  pullWithBig
//
//  Created by Lcyu on 15/6/27.
//  Copyright (c) 2015年 Our Dream. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CVC : UICollectionViewController

@end
