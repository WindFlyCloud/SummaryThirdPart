//
//  Header.m
//  PersonalPage
//
//  Created by hongjunxiao on 16/2/22.
//  Copyright © 2016年 ihj. All rights reserved.
//

#import "Header.h"

@implementation Header

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
