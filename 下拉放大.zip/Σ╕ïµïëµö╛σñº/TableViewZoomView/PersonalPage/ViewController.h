//
//  ViewController.h
//  PersonalPage
//
//  Created by hongjunxiao on 16/2/22.
//  Copyright © 2016年 ihj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>


@end

