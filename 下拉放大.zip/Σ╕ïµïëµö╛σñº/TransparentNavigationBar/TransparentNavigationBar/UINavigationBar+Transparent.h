//
//  UINavigationBar+Transparent.h
//  TransparentNavigationBar
//
//  Created by Michael on 15/11/20.
//  Copyright © 2015年 com.51fanxing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (Transparent)

- (void)js_setBackgroundColor:(UIColor *)backgroundColor;

- (void)js_reset;

@end
