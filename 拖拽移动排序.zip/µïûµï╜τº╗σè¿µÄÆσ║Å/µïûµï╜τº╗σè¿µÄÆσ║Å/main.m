//
//  main.m
//  拖拽移动排序
//
//  Created by lixiya on 15/9/9.
//  Copyright (c) 2015年 lixiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
