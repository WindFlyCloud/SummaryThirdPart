//
//  ViewController.h
//  BMWaveDemo
//
//  Created by skyming on 9/29/14.
//  Copyright (c) 2014 Sensoro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

