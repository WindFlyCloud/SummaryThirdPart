//
//  LuJinSuoOrderDetailCell.h
//  CurveLineDemo
//
//  Created by apple on 16/3/3.
//  Copyright © 2016年 MZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LuJinSuoOrderDetailCell : UITableViewCell

@end
