//
//  InsuranceModel.h
//  PANewToapAPP
//
//  Created by apple on 15/8/20.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InsuranceModel : NSObject
@property(nonatomic,strong)NSString * totalAmount;//个人保单总额
@property(nonatomic,strong)NSString * adviceCoveringAmount;//建议覆盖


@end
