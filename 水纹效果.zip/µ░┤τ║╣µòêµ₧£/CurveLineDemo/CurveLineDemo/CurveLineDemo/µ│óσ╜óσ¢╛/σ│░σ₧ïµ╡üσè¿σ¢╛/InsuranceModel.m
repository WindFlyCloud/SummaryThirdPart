//
//  InsuranceModel.m
//  PANewToapAPP
//
//  Created by apple on 15/8/20.
//  Copyright (c) 2015年 Gavin. All rights reserved.
//

#import "InsuranceModel.h"

@implementation InsuranceModel
-(id)init{
    
    self = [super init];
    if (self)
    {
       
        
    }
    return self;
}
@end
