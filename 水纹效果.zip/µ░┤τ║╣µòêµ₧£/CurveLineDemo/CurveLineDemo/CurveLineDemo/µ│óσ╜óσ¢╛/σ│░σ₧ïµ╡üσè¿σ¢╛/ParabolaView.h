//
//  ParabolaView.h
//  CurveLineDemo
//
//  Created by apple on 15/8/18.
//  Copyright (c) 2015年 MZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParabolaView : UIView

@property (nonatomic,strong) NSString * currentCoverageHeight;//波纹高度
- (void)stopWave;
@end
