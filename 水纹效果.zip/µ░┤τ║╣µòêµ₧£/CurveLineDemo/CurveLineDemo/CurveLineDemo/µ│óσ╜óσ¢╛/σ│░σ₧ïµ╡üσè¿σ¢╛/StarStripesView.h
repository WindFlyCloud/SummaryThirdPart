//
//  StarStripesView.h
//  CurveLineDemo
//
//  Created by apple on 15/8/18.
//  Copyright (c) 2015年 MZ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StarStripesView : UIView
@property (nonatomic,strong) NSString *policylevel;
@end
