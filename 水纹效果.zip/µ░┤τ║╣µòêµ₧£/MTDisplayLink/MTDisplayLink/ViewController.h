//
//  ViewController.h
//  MTDisplayLink
//
//  Created by mtt0150 on 15/9/7.
//  Copyright (c) 2015年 MT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

