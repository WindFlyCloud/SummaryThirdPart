//
//  GLIRViewController.h
//  PoppleDemo
//
//  Created by LEA on 15/9/30.
//  Copyright © 2015年 LEA. All rights reserved.
//

#import <GLKit/GLKit.h>
#import "RippleModel.h"

@interface GLIRViewController : GLKViewController
{
    RippleModel *_ripple;
    CADisplayLink* displayLink;
    BOOL stopUdpate;
}

@property (nonatomic, strong) NSString * rippleImageName;

- (void)render:(CADisplayLink*)displayLink;
- (void)cleanRipple;

@end
