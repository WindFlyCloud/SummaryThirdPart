//
//  ViewController.m
//  PoppleDemo
//
//  Created by LEA on 15/9/30.
//  Copyright © 2015年 LEA. All rights reserved.
//

#import "ViewController.h"
#import "RippleModel.h"
#import "RippleView.h"

@interface ViewController ()
{
    RippleView  *rippleView;
}
@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImage *image = [UIImage imageNamed:@"home_top_bg"];
    EAGLContext *context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    rippleView = [[RippleView alloc] initWithFrame:CGRectMake(0, 0, image.size.width, image.size.height)
                                           context:context];
    [self.view addSubview:rippleView];
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)];
    [rippleView addGestureRecognizer:pan];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleGesture:)];
    [rippleView addGestureRecognizer:tap];
}

- (void)handleGesture:(UITapGestureRecognizer *)gesture
{
    CGPoint location = [gesture locationInView:rippleView];
    [rippleView.ripple initiateRippleAtLocation:location];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
