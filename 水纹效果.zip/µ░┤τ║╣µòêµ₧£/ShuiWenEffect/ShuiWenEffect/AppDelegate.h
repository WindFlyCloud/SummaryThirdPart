//
//  AppDelegate.h
//  ShuiWenEffect
//
//  Created by Grace Leo on 13-12-19.
//  Copyright (c) 2013年 Grace Leo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
